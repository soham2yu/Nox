export interface Property {
  id: string
  name: string
  units: number
  occupancy: number
  revenue: number
  address: string
}

export interface MaintenanceTicket {
  id: string
  property: string
  issue: string
  priority: "low" | "medium" | "high"
  status: "urgent" | "in-progress" | "scheduled" | "completed"
  technician: string
  created: string
}

export interface AIInsight {
  type: "churn_risk" | "pricing_optimization" | "preventative_maintenance"
  property_id: string
  risk_score?: number
  potential_revenue?: number
  recommendation: string
  action_priority: "high" | "medium" | "low"
}

export interface Expense {
  id: string
  category: string
  amount: number
  tax_status: "deductible" | "non_deductible" | "pending_review"
  date: string
  description: string
}
