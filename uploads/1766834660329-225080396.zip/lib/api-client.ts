// Centralized API client for frontend components
interface FetchOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE"
  body?: unknown
  headers?: Record<string, string>
}

async function apiCall(endpoint: string, options: FetchOptions = {}) {
  const { method = "GET", body, headers = {} } = options

  try {
    const response = await fetch(`/api${endpoint}`, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
    })

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("[API Error]", endpoint, error)
    throw error
  }
}

export const api = {
  properties: {
    getAll: () => apiCall("/properties"),
    create: (data: unknown) => apiCall("/properties", { method: "POST", body: data }),
  },
  maintenance: {
    getAll: (status?: string) => apiCall(`/maintenance${status ? `?status=${status}` : ""}`),
    create: (data: unknown) => apiCall("/maintenance", { method: "POST", body: data }),
  },
  disputes: {
    getAll: (filters?: Record<string, string>) => {
      const params = new URLSearchParams(filters).toString()
      return apiCall(`/disputes${params ? `?${params}` : ""}`)
    },
    create: (data: unknown) => apiCall("/disputes", { method: "POST", body: data }),
  },
  financial: {
    get: (category?: string) => apiCall(`/financial${category ? `?category=${category}` : ""}`),
    save: (data: unknown) => apiCall("/financial", { method: "POST", body: data }),
  },
  analytics: {
    get: (period?: string) => apiCall(`/analytics${period ? `?period=${period}` : ""}`),
  },
}
