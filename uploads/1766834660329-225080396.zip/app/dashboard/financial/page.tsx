"use client"

import { motion } from "framer-motion"
import { DollarSign, TrendingUp, PieChartIcon } from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const expenseData = [
  { category: "Maintenance", amount: 5000 },
  { category: "Utilities", amount: 3200 },
  { category: "Insurance", amount: 2800 },
  { category: "Salaries", amount: 8000 },
  { category: "Taxes", amount: 4500 },
]

export default function FinancialPage() {
  const totalRevenue = 125400
  const totalExpenses = 23500
  const netProfit = totalRevenue - totalExpenses
  const taxDue = netProfit * 0.15

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold mb-2">Financial Overview</h1>
        <p className="text-muted-foreground">Track expenses and optimize tax preparation</p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            icon: DollarSign,
            label: "Total Revenue",
            value: `$${(totalRevenue / 1000).toFixed(1)}K`,
            trend: "+15%",
            trendColor: "text-green-500",
          },
          {
            icon: DollarSign,
            label: "Total Expenses",
            value: `$${(totalExpenses / 1000).toFixed(1)}K`,
            trend: "-8%",
            trendColor: "text-red-500",
          },
          {
            icon: TrendingUp,
            label: "Net Profit",
            value: `$${(netProfit / 1000).toFixed(1)}K`,
            trend: "+18%",
            trendColor: "text-primary",
          },
          {
            icon: PieChartIcon,
            label: "Tax Due (15%)",
            value: `$${(taxDue / 1000).toFixed(1)}K`,
            trend: "Due Soon",
            trendColor: "text-yellow-500",
          },
        ].map((kpi, i) => {
          const Icon = kpi.icon
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="rounded-xl bg-card border border-border shadow-lg p-6 hover:shadow-xl transition-all hover:border-primary/30"
            >
              <div className="flex items-start justify-between mb-4">
                <Icon className="w-6 h-6 text-primary flex-shrink-0" />
                <p className={`text-xs ${kpi.trendColor} bg-primary/10 px-2 py-1 rounded-full`}>{kpi.trend}</p>
              </div>
              <p className="text-sm text-muted-foreground mb-1">{kpi.label}</p>
              <p className="text-3xl font-bold">{kpi.value}</p>
            </motion.div>
          )
        })}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="rounded-xl bg-card border border-border shadow-lg p-6 hover:shadow-xl transition-all hover:border-primary/30"
      >
        <h3 className="font-semibold text-lg mb-6">Expense Breakdown</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={expenseData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#444" />
            <XAxis dataKey="category" stroke="#999" />
            <YAxis stroke="#999" />
            <Tooltip />
            <Bar dataKey="amount" fill="#ff94b2" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="rounded-xl bg-card border border-border shadow-lg p-6 border-primary/30 hover:shadow-xl transition-all hover:border-primary/30"
      >
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
            <DollarSign className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Tax Optimization Tip</h3>
            <p className="text-muted-foreground mb-4">
              You can deduct an additional $3,200 in maintenance expenses this quarter. Make sure to collect all
              receipts before the deadline.
            </p>
            <button className="px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95">
              View Tax Report
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
