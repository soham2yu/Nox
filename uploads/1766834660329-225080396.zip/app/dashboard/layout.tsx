"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Sidebar, SidebarBody, SidebarLink } from "@/components/ui/sidebar"
import ShaderBackground from "@/components/ui/shader-background"
import { motion } from "framer-motion"
import { LayoutDashboard, User, Settings, LogOut, BarChart3, Wrench, MessageSquare, DollarSign } from "lucide-react"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/login")
    } else {
      setUser(JSON.parse(userData))
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const links = [
    {
      label: "Dashboard",
      href: "/dashboard",
      icon: <LayoutDashboard className="text-[#FF94B2] h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "AI Insights",
      href: "/dashboard/insights",
      icon: <BarChart3 className="text-[#FF94B2] h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "Maintenance",
      href: "/dashboard/maintenance",
      icon: <Wrench className="text-[#FF94B2] h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "Communications",
      href: "/dashboard/communications",
      icon: <MessageSquare className="text-[#FF94B2] h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "Financial",
      href: "/dashboard/financial",
      icon: <DollarSign className="text-[#FF94B2] h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "Profile",
      href: "/dashboard/profile",
      icon: <User className="text-[#FF94B2] h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "Settings",
      href: "/dashboard/settings",
      icon: <Settings className="text-[#FF94B2] h-5 w-5 flex-shrink-0" />,
    },
  ]

  if (!mounted || !user) {
    return null
  }

  return (
    <main className="min-h-screen w-full relative">
      <ShaderBackground />

      <div className="relative z-20 flex flex-col md:flex-row h-screen">
        <Sidebar open={open} setOpen={setOpen}>
          <SidebarBody className="justify-between gap-10">
            <div className="flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
              <div className="font-bold text-lg mb-8 px-2 py-1">
                <span className="bg-gradient-to-r from-[#FF94B2] to-[#FFDBE8] bg-clip-text text-transparent">
                  PropertyHub
                </span>
              </div>

              <nav className="mt-8 flex flex-col gap-2">
                {links.map((link, idx) => (
                  <SidebarLink key={idx} link={link} />
                ))}
              </nav>
            </div>

            <div className="space-y-3">
              <SidebarLink
                link={{
                  label: user?.name || "User",
                  href: "/dashboard/profile",
                  icon: (
                    <div className="h-7 w-7 flex-shrink-0 rounded-full bg-gradient-to-r from-[#FF94B2] to-[#FFDBE8] flex items-center justify-center text-white font-semibold text-sm">
                      {user?.name?.[0] || "U"}
                    </div>
                  ),
                }}
              />
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-start gap-2 px-2 py-2 rounded-lg hover:bg-red-500/10 transition-all text-red-500 group/sidebar"
              >
                <LogOut className="h-5 w-5 flex-shrink-0" />
                <motion.span
                  animate={{
                    display: open ? "inline-block" : "none",
                    opacity: open ? 1 : 0,
                  }}
                  className="text-sm whitespace-pre"
                >
                  Logout
                </motion.span>
              </button>
            </div>
          </SidebarBody>
        </Sidebar>

        <div className="flex-1 overflow-auto bg-white/5 backdrop-blur-sm">
          <div className="p-6 md:p-10">{children}</div>
        </div>
      </div>
    </main>
  )
}
