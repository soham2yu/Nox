"use client"

import { motion } from "framer-motion"
import { TrendingUp, AlertTriangle, Target, Zap, BarChart3 } from "lucide-react"
import { useState } from "react"

export default function InsightsPage() {
  const [activeTab, setActiveTab] = useState("all")

  const insights = [
    {
      id: 1,
      type: "churn",
      icon: TrendingUp,
      title: "Tenant Churn Prediction",
      description: "Unit 305 has a 35% risk of vacancy within 3 months",
      color: "text-red-500",
      action: "View Recommendation",
      detail: "Historical data shows similar patterns. Consider a lease renewal incentive.",
    },
    {
      id: 2,
      type: "pricing",
      icon: Target,
      title: "Dynamic Pricing Opportunity",
      description: "Market analysis suggests 8-12% rent increase possible",
      color: "text-green-500",
      action: "View Analysis",
      detail: "Current market conditions are favorable for rate optimization.",
    },
    {
      id: 3,
      type: "maintenance",
      icon: AlertTriangle,
      title: "Preventative Maintenance Alert",
      description: "HVAC system requires maintenance in 30 days",
      color: "text-yellow-500",
      action: "Schedule Maintenance",
      detail: "Early maintenance can prevent costly emergency repairs.",
    },
    {
      id: 4,
      type: "revenue",
      icon: Zap,
      title: "Revenue Optimization",
      description: "3 units can be converted to higher rental category",
      color: "text-blue-500",
      action: "View Details",
      detail: "Recent renovations make these units attractive to premium tenants.",
    },
  ]

  const filteredInsights =
    activeTab === "all" ? insights : insights.filter((i) => i.type.includes(activeTab.slice(0, 3)))

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold mb-2">AI Insights</h1>
        <p className="text-muted-foreground">Predictive analytics and smart recommendations</p>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3">
        {[
          { label: "All Insights", value: "all" },
          { label: "Churn Prediction", value: "churn" },
          { label: "Pricing", value: "pricing" },
          { label: "Maintenance", value: "maintenance" },
        ].map((tab) => (
          <button
            key={tab.value}
            onClick={() => setActiveTab(tab.value)}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === tab.value
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </motion.div>

      <div className="grid md:grid-cols-2 gap-6">
        {filteredInsights.map((insight, idx) => {
          const Icon = insight.icon
          return (
            <motion.div
              key={insight.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="rounded-xl bg-card border border-border shadow-lg p-8 hover:shadow-xl transition-all hover:scale-105 hover:border-primary/30"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className={`p-3 rounded-lg bg-primary/10 ${insight.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{insight.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{insight.description}</p>
                </div>
              </div>

              <p className="text-sm text-muted-foreground mb-4 p-3 bg-muted/50 rounded-lg">{insight.detail}</p>

              <button className="w-full px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95">
                {insight.action}
              </button>
            </motion.div>
          )
        })}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="rounded-xl bg-card border border-border shadow-lg p-6 hover:shadow-xl transition-all hover:border-primary/30"
      >
        <div className="flex items-center gap-2 mb-6">
          <BarChart3 className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-semibold">Performance Metrics</h2>
        </div>

        <div className="grid md:grid-cols-4 gap-4">
          {[
            { label: "Avg Occupancy", value: "87%", trend: "+2%" },
            { label: "Revenue Growth", value: "+14%", trend: "+2.5%" },
            { label: "Tenant Retention", value: "92%", trend: "+3%" },
            { label: "Maintenance Cost", value: "-8%", trend: "-2%" },
          ].map((metric, idx) => (
            <div key={idx} className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">{metric.label}</p>
              <p className="text-2xl font-bold">{metric.value}</p>
              <p className="text-xs text-green-500 mt-1">{metric.trend}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  )
}
