"use client"

import { motion } from "framer-motion"
import { Wrench, AlertCircle, CheckCircle2, Plus } from "lucide-react"
import { useState } from "react"

export default function MaintenancePage() {
  const [filterStatus, setFilterStatus] = useState("all")
  const [expandedTicket, setExpandedTicket] = useState<number | null>(null)

  const tickets = [
    {
      id: 1,
      title: "Roof Repair",
      status: "In Progress",
      priority: "High",
      unit: "Unit 405",
      date: "2 days ago",
      description: "Roof leak repair and waterproofing",
      assignee: "John Contractor",
    },
    {
      id: 2,
      title: "Plumbing Issue",
      status: "Completed",
      priority: "Medium",
      unit: "Unit 302",
      date: "5 days ago",
      description: "Fixed leaky faucet and water pressure issue",
      assignee: "Sarah Plumber",
    },
    {
      id: 3,
      title: "HVAC Maintenance",
      status: "Pending",
      priority: "High",
      unit: "Building A",
      date: "1 day ago",
      description: "Quarterly HVAC filter replacement and inspection",
      assignee: "Unassigned",
    },
    {
      id: 4,
      title: "Door Lock Replacement",
      status: "In Progress",
      priority: "Low",
      unit: "Unit 210",
      date: "3 days ago",
      description: "Replace broken door lock mechanism",
      assignee: "Mike Locksmith",
    },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Completed":
        return <CheckCircle2 className="w-5 h-5 text-green-500" />
      case "In Progress":
        return <Wrench className="w-5 h-5 text-primary animate-spin" />
      case "Pending":
        return <AlertCircle className="w-5 h-5 text-yellow-500" />
      default:
        return null
    }
  }

  const filteredTickets =
    filterStatus === "all" ? tickets : tickets.filter((t) => t.status.toLowerCase() === filterStatus.toLowerCase())

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-start"
      >
        <div>
          <h1 className="text-4xl font-bold mb-2">Maintenance Tickets</h1>
          <p className="text-muted-foreground">Manage and track maintenance requests</p>
        </div>
        <button className="px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95 flex items-center gap-2">
          <Plus className="w-4 h-4" />
          New Ticket
        </button>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3 flex-wrap">
        {[
          { label: "All", value: "all", count: tickets.length },
          { label: "Pending", value: "pending", count: tickets.filter((t) => t.status === "Pending").length },
          {
            label: "In Progress",
            value: "in progress",
            count: tickets.filter((t) => t.status === "In Progress").length,
          },
          { label: "Completed", value: "completed", count: tickets.filter((t) => t.status === "Completed").length },
        ].map((filter) => (
          <button
            key={filter.value}
            onClick={() => setFilterStatus(filter.value)}
            className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center gap-2 ${
              filterStatus === filter.value
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {filter.label}
            <span className="text-xs bg-white/20 px-2 py-1 rounded-full">{filter.count}</span>
          </button>
        ))}
      </motion.div>

      <div className="space-y-4">
        {filteredTickets.map((ticket, idx) => (
          <motion.div
            key={ticket.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="rounded-xl bg-card border border-border shadow-lg overflow-hidden hover:shadow-lg transition-all"
          >
            <button
              onClick={() => setExpandedTicket(expandedTicket === ticket.id ? null : ticket.id)}
              className="w-full p-6 flex items-start justify-between cursor-pointer"
            >
              <div className="flex items-start gap-4 flex-1 text-left">
                <div className="mt-1">{getStatusIcon(ticket.status)}</div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold text-lg">{ticket.title}</h3>
                    <span
                      className={`text-xs font-semibold px-2 py-1 rounded-full ${
                        ticket.priority === "High"
                          ? "bg-red-500/20 text-red-500"
                          : ticket.priority === "Medium"
                            ? "bg-yellow-500/20 text-yellow-500"
                            : "bg-green-500/20 text-green-500"
                      }`}
                    >
                      {ticket.priority}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{ticket.unit}</p>
                </div>
              </div>
              <div className="text-right">
                <p
                  className={`text-sm font-medium ${
                    ticket.status === "Completed"
                      ? "text-green-500"
                      : ticket.status === "In Progress"
                        ? "text-primary"
                        : "text-yellow-500"
                  }`}
                >
                  {ticket.status}
                </p>
                <p className="text-xs text-muted-foreground">{ticket.date}</p>
              </div>
            </button>

            {expandedTicket === ticket.id && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="border-t border-border px-6 py-4 bg-muted/30 space-y-4"
              >
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Description</p>
                  <p className="font-medium">{ticket.description}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Assigned To</p>
                  <p className="font-medium">{ticket.assignee}</p>
                </div>
                <div className="flex gap-3 pt-2">
                  <button className="px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95 flex-1">
                    Update Status
                  </button>
                  <button className="px-4 py-2 rounded-lg font-medium transition-all border border-border text-foreground hover:bg-muted flex-1">
                    Add Note
                  </button>
                </div>
              </motion.div>
            )}
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="grid md:grid-cols-4 gap-4"
      >
        {[
          { label: "Total Tickets", value: tickets.length, color: "text-blue-500" },
          {
            label: "In Progress",
            value: tickets.filter((t) => t.status === "In Progress").length,
            color: "text-primary",
          },
          { label: "Pending", value: tickets.filter((t) => t.status === "Pending").length, color: "text-yellow-500" },
          {
            label: "Completed",
            value: tickets.filter((t) => t.status === "Completed").length,
            color: "text-green-500",
          },
        ].map((stat, idx) => (
          <div
            key={idx}
            className="rounded-xl bg-card border border-border shadow-lg p-4 text-center hover:shadow-xl transition-all hover:border-primary/30"
          >
            <p className={`text-2xl font-bold ${stat.color} mb-1`}>{stat.value}</p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </motion.div>
    </div>
  )
}
