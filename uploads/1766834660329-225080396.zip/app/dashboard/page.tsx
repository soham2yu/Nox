"use client"

import { motion } from "framer-motion"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from "recharts"
import { Home, DollarSign, AlertCircle, Users, Zap } from "lucide-react"

const dashboardData = [
  { month: "Jan", revenue: 4000, expenses: 2400 },
  { month: "Feb", revenue: 3000, expenses: 1398 },
  { month: "Mar", revenue: 2000, expenses: 9800 },
  { month: "Apr", revenue: 2780, expenses: 3908 },
  { month: "May", revenue: 1890, expenses: 4800 },
  { month: "Jun", revenue: 2390, expenses: 3200 },
]

const occupancyData = [
  { name: "Occupied", value: 85, fill: "#ff94b2" },
  { name: "Vacant", value: 15, fill: "#ffdbe8" },
]

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's your property overview.</p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { icon: Home, label: "Total Properties", value: "24", change: "+2.5%", color: "text-blue-500" },
          { icon: DollarSign, label: "Monthly Revenue", value: "$45.2K", change: "+12%", color: "text-green-500" },
          { icon: Users, label: "Occupancy Rate", value: "85%", change: "+5%", color: "text-primary" },
          { icon: AlertCircle, label: "Pending Issues", value: "8", change: "-3", color: "text-yellow-500" },
        ].map((kpi, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="rounded-xl bg-card border border-border shadow-lg p-6 hover:shadow-xl transition-all hover:border-primary/30"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm text-muted-foreground mb-2">{kpi.label}</p>
                <p className="text-3xl font-bold">{kpi.value}</p>
                <p className="text-xs text-primary mt-2 font-medium">{kpi.change}</p>
              </div>
              <div className={`p-3 rounded-lg bg-primary/10 ${kpi.color}`}>
                <kpi.icon className="w-6 h-6" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 rounded-xl bg-card border border-border shadow-lg p-6 hover:shadow-xl transition-all hover:border-primary/30"
        >
          <h3 className="font-semibold mb-6 text-lg">Revenue Overview</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={dashboardData}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ff94b2" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#ff94b2" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis stroke="#999" />
              <YAxis stroke="#999" />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="#ff94b2"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorRevenue)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Occupancy Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="rounded-xl bg-card border border-border shadow-lg p-6 hover:shadow-xl transition-all hover:border-primary/30"
        >
          <h3 className="font-semibold mb-6 text-lg">Occupancy</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={occupancyData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} dataKey="value">
                {occupancyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Recent Activity */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="rounded-xl bg-card border border-border shadow-lg p-6 hover:shadow-xl transition-all hover:border-primary/30"
      >
        <h3 className="font-semibold mb-6 text-lg">Recent Activity</h3>
        <div className="space-y-3">
          {[
            {
              title: "Maintenance Ticket #2401",
              desc: "Roof repair completed",
              time: "2 hours ago",
              icon: Zap,
              color: "text-green-500",
            },
            {
              title: "Tenant Move-in",
              desc: "Unit 405 - John Smith",
              time: "1 day ago",
              icon: Users,
              color: "text-blue-500",
            },
            {
              title: "Payment Received",
              desc: "$2,450 from Unit 302",
              time: "2 days ago",
              icon: DollarSign,
              color: "text-primary",
            },
            {
              title: "Maintenance Alert",
              desc: "HVAC maintenance due",
              time: "3 days ago",
              icon: AlertCircle,
              color: "text-yellow-500",
            },
          ].map((item, i) => {
            const Icon = item.icon
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + i * 0.05 }}
                className="flex items-start gap-4 p-4 bg-muted/50 rounded-lg hover:bg-muted transition-colors"
              >
                <div className={`mt-1 flex-shrink-0 ${item.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{item.title}</p>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
                <p className="text-xs text-muted-foreground whitespace-nowrap">{item.time}</p>
              </motion.div>
            )
          })}
        </div>
      </motion.div>
    </div>
  )
}
