"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useTheme } from "next-themes"
import { Moon, Sun, Bell, Shield, LogOut, Lock, Eye, Database, Palette } from "lucide-react"
import { useRouter } from "next/navigation"
import { CheckCircle2 } from "lucide-react"

export default function SettingsPage() {
  const { theme, setTheme } = useTheme()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const [activeTab, setActiveTab] = useState("appearance")
  const [saveSuccess, setSaveSuccess] = useState(false)
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    maintenance: true,
    billing: true,
    updates: false,
  })

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const handleSaveSettings = () => {
    localStorage.setItem("notifications", JSON.stringify(notifications))
    setSaveSuccess(true)
    setTimeout(() => setSaveSuccess(false), 3000)
  }

  if (!mounted) return null

  const tabs = [
    { id: "appearance", label: "Appearance", icon: Palette },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "security", label: "Security", icon: Shield },
  ]

  return (
    <div className="space-y-8 max-w-3xl">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold mb-2">Settings</h1>
        <p className="text-muted-foreground">Manage your preferences and account settings</p>
      </motion.div>

      {saveSuccess && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg text-green-600 dark:text-green-400 font-medium flex items-center gap-2"
        >
          <CheckCircle2 className="w-5 h-5" />
          Settings saved successfully!
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex gap-2 border-b border-border"
      >
        {tabs.map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 font-medium transition-all border-b-2 ${
                activeTab === tab.id
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          )
        })}
      </motion.div>

      {activeTab === "appearance" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl bg-card border border-border shadow-lg p-8 space-y-6 hover:shadow-xl transition-all hover:border-primary/30"
        >
          <div>
            <h3 className="text-xl font-semibold mb-4">Theme</h3>
            <p className="text-muted-foreground mb-4">Choose your preferred color theme</p>
            <div className="grid grid-cols-2 gap-4">
              {[
                { value: "light", label: "Light", icon: Sun, desc: "Clean and bright" },
                { value: "dark", label: "Dark", icon: Moon, desc: "Easy on the eyes" },
              ].map((t) => {
                const Icon = t.icon
                return (
                  <button
                    key={t.value}
                    onClick={() => setTheme(t.value)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      theme === t.value ? "border-primary bg-primary/10" : "border-border hover:border-primary/30"
                    }`}
                  >
                    <Icon className="w-6 h-6 mb-2" />
                    <p className="font-medium">{t.label}</p>
                    <p className="text-xs text-muted-foreground">{t.desc}</p>
                  </button>
                )
              })}
            </div>
          </div>

          <div className="pt-6 border-t border-border">
            <h3 className="text-lg font-semibold mb-4">Display Options</h3>
            <div className="space-y-3">
              {[
                { label: "Compact View", desc: "Show less spacing in lists" },
                { label: "Animations", desc: "Enable smooth transitions" },
                { label: "High Contrast", desc: "Better readability" },
              ].map((option, idx) => (
                <label
                  key={idx}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/30 cursor-pointer transition-colors"
                >
                  <input type="checkbox" defaultChecked={idx !== 2} className="w-5 h-5 rounded" />
                  <div className="flex-1">
                    <p className="font-medium text-sm">{option.label}</p>
                    <p className="text-xs text-muted-foreground">{option.desc}</p>
                  </div>
                </label>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {activeTab === "notifications" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="rounded-xl bg-card border border-border shadow-lg p-8 hover:shadow-xl transition-all hover:border-primary/30">
            <h3 className="text-xl font-semibold mb-6">Email Notifications</h3>
            <div className="space-y-4">
              {[
                { key: "email", label: "Email Notifications", desc: "Receive updates via email" },
                { key: "push", label: "Push Notifications", desc: "Browser push notifications" },
                { key: "maintenance", label: "Maintenance Alerts", desc: "Get alerts for maintenance issues" },
                { key: "billing", label: "Billing Notifications", desc: "Receive billing updates" },
                { key: "updates", label: "Product Updates", desc: "Learn about new features" },
              ].map((notif) => (
                <label
                  key={notif.key}
                  className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                >
                  <div>
                    <p className="font-medium">{notif.label}</p>
                    <p className="text-sm text-muted-foreground">{notif.desc}</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={notifications[notif.key as keyof typeof notifications]}
                    onChange={(e) =>
                      setNotifications({
                        ...notifications,
                        [notif.key]: e.target.checked,
                      })
                    }
                    className="w-5 h-5 rounded"
                  />
                </label>
              ))}
            </div>
          </div>

          <div className="rounded-xl bg-card border border-border shadow-lg p-8 hover:shadow-xl transition-all hover:border-primary/30">
            <h3 className="text-lg font-semibold mb-4">Notification Frequency</h3>
            <div className="space-y-2">
              {["Real-time", "Daily Digest", "Weekly Summary"].map((freq, idx) => (
                <label key={idx} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/30 cursor-pointer">
                  <input type="radio" name="frequency" defaultChecked={idx === 0} className="w-4 h-4" />
                  <p className="font-medium text-sm">{freq}</p>
                </label>
              ))}
            </div>
          </div>

          <button
            onClick={handleSaveSettings}
            className="w-full px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95"
          >
            Save Notification Settings
          </button>
        </motion.div>
      )}

      {activeTab === "security" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl bg-card border border-border shadow-lg p-8 space-y-6 hover:shadow-xl transition-all hover:border-primary/30"
        >
          <h3 className="text-xl font-semibold">Security Options</h3>

          <div className="space-y-3">
            {[
              { icon: Lock, label: "Change Password", desc: "Update your password" },
              { icon: Eye, label: "Two-Factor Authentication", desc: "Add an extra layer of security" },
              { icon: Database, label: "Active Sessions", desc: "Manage your logged-in devices" },
            ].map((option, idx) => {
              const Icon = option.icon
              return (
                <button
                  key={idx}
                  className="w-full flex items-start justify-between p-4 bg-muted/30 hover:bg-muted/50 rounded-lg transition-colors text-left"
                >
                  <div className="flex items-start gap-3">
                    <Icon className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium">{option.label}</p>
                      <p className="text-sm text-muted-foreground">{option.desc}</p>
                    </div>
                  </div>
                  <span className="text-primary font-medium">Configure</span>
                </button>
              )
            })}
          </div>

          <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
            <p className="text-sm text-yellow-600 dark:text-yellow-400">
              For your security, we recommend enabling two-factor authentication.
            </p>
          </div>
        </motion.div>
      )}

      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        onClick={handleLogout}
        className="w-full px-6 py-3 bg-red-500/10 hover:bg-red-500/20 border-2 border-red-500/30 rounded-lg text-red-500 font-semibold transition-all flex items-center justify-center gap-2"
      >
        <LogOut className="w-5 h-5" />
        Logout
      </motion.button>
    </div>
  )
}
