"use client"

import { motion } from "framer-motion"
import { MessageSquare, AlertCircle, CheckCircle2, Send } from "lucide-react"
import { useState } from "react"

export default function CommunicationsPage() {
  const [activeTab, setActiveTab] = useState("disputes")
  const [newMessage, setNewMessage] = useState("")
  const [selectedTenant, setSelectedTenant] = useState("")

  const disputes = [
    { id: 1, tenant: "John Smith", issue: "Noise complaint", status: "Open", priority: "High" },
    { id: 2, tenant: "Sarah Johnson", issue: "Maintenance request", status: "In Review", priority: "Medium" },
    { id: 3, tenant: "Mike Brown", issue: "Billing inquiry", status: "Resolved", priority: "Low" },
  ]

  const tenants = ["John Smith", "Sarah Johnson", "Mike Brown", "Emma Wilson"]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Open":
        return "bg-blue-500/20 text-blue-400"
      case "In Review":
        return "bg-primary/20 text-primary"
      case "Resolved":
        return "bg-green-500/20 text-green-400"
      default:
        return ""
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "High":
        return "bg-red-500/20 text-red-400"
      case "Medium":
        return "bg-yellow-500/20 text-yellow-400"
      case "Low":
        return "bg-green-500/20 text-green-400"
      default:
        return ""
    }
  }

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold mb-2">Communications Hub</h1>
        <p className="text-muted-foreground">Manage tenant disputes and communications</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex gap-3 border-b border-border"
      >
        {[
          { id: "disputes", label: "Disputes", icon: AlertCircle },
          { id: "messages", label: "Messages", icon: MessageSquare },
        ].map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 font-medium transition-all border-b-2 ${
                activeTab === tab.id
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          )
        })}
      </motion.div>

      {activeTab === "disputes" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="rounded-xl bg-card border border-border shadow-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted/50 border-b border-border">
                <tr>
                  <th className="px-6 py-4 text-left font-semibold">Tenant</th>
                  <th className="px-6 py-4 text-left font-semibold">Issue</th>
                  <th className="px-6 py-4 text-left font-semibold">Priority</th>
                  <th className="px-6 py-4 text-left font-semibold">Status</th>
                  <th className="px-6 py-4 text-left font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {disputes.map((dispute, idx) => (
                  <motion.tr
                    key={dispute.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="border-b border-border hover:bg-muted/30 transition-colors"
                  >
                    <td className="px-6 py-4 text-sm font-medium">{dispute.tenant}</td>
                    <td className="px-6 py-4 text-sm">{dispute.issue}</td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${getPriorityColor(dispute.priority)}`}
                      >
                        {dispute.priority}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {dispute.status === "Resolved" && <CheckCircle2 className="w-4 h-4 text-green-500" />}
                        {dispute.status === "In Review" && <AlertCircle className="w-4 h-4 text-yellow-500" />}
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(dispute.status)}`}
                        >
                          {dispute.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <button className="text-primary hover:text-primary/80 text-sm font-medium transition-colors">
                        View
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {activeTab === "messages" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="grid md:grid-cols-3 gap-4">
            {[
              {
                label: "Open Disputes",
                value: disputes.filter((d) => d.status === "Open").length,
                color: "text-blue-500",
              },
              {
                label: "In Review",
                value: disputes.filter((d) => d.status === "In Review").length,
                color: "text-yellow-500",
              },
              {
                label: "Resolved",
                value: disputes.filter((d) => d.status === "Resolved").length,
                color: "text-green-500",
              },
            ].map((stat, idx) => (
              <div
                key={idx}
                className="rounded-xl bg-card border border-border shadow-lg p-6 text-center hover:shadow-xl transition-all hover:border-primary/30"
              >
                <p className={`text-3xl font-bold ${stat.color} mb-2`}>{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>

          <div className="rounded-xl bg-card border border-border shadow-lg p-6 space-y-4 hover:shadow-xl transition-all hover:border-primary/30">
            <h3 className="text-lg font-semibold">Send Message</h3>
            <div>
              <label className="block text-sm font-medium mb-2">Select Tenant</label>
              <select
                value={selectedTenant}
                onChange={(e) => setSelectedTenant(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
              >
                <option value="">Choose a tenant...</option>
                {tenants.map((tenant) => (
                  <option key={tenant} value={tenant}>
                    {tenant}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Message</label>
              <textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type your message here..."
                rows={4}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all resize-none"
              />
            </div>

            <button className="w-full px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95 py-3 flex items-center justify-center gap-2">
              <Send className="w-4 h-4" />
              Send Message
            </button>
          </div>
        </motion.div>
      )}
    </div>
  )
}
