"use client"

import type React from "react"
import { CheckCircle2 } from "lucide-react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Mail, User, Building2, Phone, Save, X, Camera, Briefcase } from "lucide-react"

export default function ProfilePage() {
  const [user, setUser] = useState<any>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    phone: "",
    bio: "",
    role: "Property Manager",
    properties: "24",
  })
  const [saveSuccess, setSaveSuccess] = useState(false)

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsed = JSON.parse(userData)
      setUser(parsed)
      setFormData({
        name: parsed.name || "",
        email: parsed.email || "",
        company: parsed.company || "",
        phone: parsed.phone || "",
        bio: parsed.bio || "",
        role: parsed.role || "Property Manager",
        properties: parsed.properties || "24",
      })
    }
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSave = () => {
    localStorage.setItem("user", JSON.stringify({ ...user, ...formData }))
    setUser({ ...user, ...formData })
    setIsEditing(false)
    setSaveSuccess(true)
    setTimeout(() => setSaveSuccess(false), 3000)
  }

  if (!user) return null

  return (
    <div className="space-y-8 max-w-3xl">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold mb-2">Profile</h1>
        <p className="text-muted-foreground">Manage your account information and settings</p>
      </motion.div>

      {saveSuccess && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg text-green-600 dark:text-green-400 font-medium flex items-center gap-2"
        >
          <CheckCircle2 className="w-5 h-5" />
          Profile updated successfully!
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-xl bg-card border border-border shadow-lg p-8 hover:shadow-xl transition-all hover:border-primary/30"
      >
        <div className="flex items-center gap-6 mb-6">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-gradient-to-r from-primary to-secondary flex items-center justify-center text-white text-3xl font-bold">
              {user.name?.[0] || "U"}
            </div>
            <button className="absolute bottom-0 right-0 p-2 bg-primary rounded-full text-white hover:bg-primary/80 transition-all">
              <Camera className="w-4 h-4" />
            </button>
          </div>
          <div>
            <h2 className="text-2xl font-bold">{user.name}</h2>
            <p className="text-muted-foreground">{user.email}</p>
            <p className="text-sm text-primary font-medium mt-2">{formData.role}</p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="rounded-xl bg-card border border-border shadow-lg p-8 hover:shadow-xl transition-all hover:border-primary/30"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold">Account Information</h3>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="text-primary hover:text-primary/80 transition-colors flex items-center gap-2 font-medium"
          >
            {isEditing ? (
              <>
                <X className="w-4 h-4" />
                Cancel
              </>
            ) : (
              <>Edit</>
            )}
          </button>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium">Full Name</label>
            {isEditing ? (
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
              />
            ) : (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <User className="w-5 h-5 text-primary flex-shrink-0" />
                <p>{formData.name}</p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Email</label>
            {isEditing ? (
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
              />
            ) : (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                <p>{formData.email}</p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Role</label>
            {isEditing ? (
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
              >
                <option>Property Manager</option>
                <option>Property Owner</option>
                <option>Facility Manager</option>
                <option>Administrator</option>
              </select>
            ) : (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Briefcase className="w-5 h-5 text-primary flex-shrink-0" />
                <p>{formData.role}</p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Company</label>
            {isEditing ? (
              <input
                type="text"
                name="company"
                value={formData.company}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
              />
            ) : (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Building2 className="w-5 h-5 text-primary flex-shrink-0" />
                <p>{formData.company || "Not set"}</p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Phone</label>
            {isEditing ? (
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
              />
            ) : (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                <p>{formData.phone || "Not set"}</p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Bio</label>
            {isEditing ? (
              <textarea
                name="bio"
                value={formData.bio}
                onChange={handleChange}
                rows={4}
                placeholder="Tell us about yourself..."
                className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
              />
            ) : (
              <p className="p-3 rounded-lg bg-muted/50 text-muted-foreground">{formData.bio || "No bio added yet"}</p>
            )}
          </div>

          {isEditing && (
            <button
              onClick={handleSave}
              className="w-full px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95 py-3 flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Changes
            </button>
          )}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="grid md:grid-cols-3 gap-4"
      >
        {[
          { label: "Properties Managed", value: formData.properties, icon: Building2 },
          { label: "Account Status", value: "Active", icon: User },
          { label: "Member Since", value: "2024", icon: Phone },
        ].map((stat, idx) => {
          const Icon = stat.icon
          return (
            <div
              key={idx}
              className="rounded-xl bg-card border border-border shadow-lg p-4 flex items-center gap-4 hover:shadow-xl transition-all hover:border-primary/30"
            >
              <Icon className="w-6 h-6 text-primary flex-shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className="text-lg font-semibold">{stat.value}</p>
              </div>
            </div>
          )
        })}
      </motion.div>
    </div>
  )
}
