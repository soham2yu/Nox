import { type NextRequest, NextResponse } from "next/server"

// Mock database - in production, connect to real database
const properties = [
  {
    id: 1,
    name: "Sunset Apartments",
    address: "123 Sunset Blvd, CA 90210",
    units: 24,
    occupancy: 0.98,
    monthlyRevenue: 58000,
  },
  {
    id: 2,
    name: "Downtown Towers",
    address: "456 Market St, CA 94102",
    units: 45,
    occupancy: 0.95,
    monthlyRevenue: 95000,
  },
]

export async function GET(request: NextRequest) {
  try {
    return NextResponse.json({
      success: true,
      data: properties,
      count: properties.length,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch properties",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const newProperty = {
      id: properties.length + 1,
      ...body,
    }
    properties.push(newProperty)
    return NextResponse.json(
      {
        success: true,
        data: newProperty,
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to create property",
      },
      { status: 400 },
    )
  }
}
