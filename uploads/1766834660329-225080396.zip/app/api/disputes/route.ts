import { type NextRequest, NextResponse } from "next/server"

// Mock database
const disputes = [
  {
    id: "DSP-001",
    tenant: "Sarah Johnson",
    property: "Sunset Apartments, Unit 302",
    subject: "Noise complaint - recurring issue",
    status: "open",
    priority: "high",
    created: new Date("2024-01-03").toISOString(),
    messages: 5,
    resolution: "Pending mediation",
  },
  {
    id: "DSP-002",
    tenant: "Michael Chen",
    property: "Downtown Towers, Unit 501",
    subject: "Maintenance request not addressed",
    status: "in-review",
    priority: "medium",
    created: new Date("2023-12-30").toISOString(),
    messages: 3,
    resolution: "Under investigation",
  },
]

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get("status")
    const priority = searchParams.get("priority")

    let filtered = [...disputes]

    if (status) filtered = filtered.filter((d) => d.status === status)
    if (priority) filtered = filtered.filter((d) => d.priority === priority)

    return NextResponse.json({
      success: true,
      data: filtered,
      count: filtered.length,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch disputes",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const newDispute = {
      id: `DSP-${String(disputes.length + 1).padStart(3, "0")}`,
      created: new Date().toISOString(),
      messages: 0,
      ...body,
    }
    disputes.push(newDispute)
    return NextResponse.json(
      {
        success: true,
        data: newDispute,
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to create dispute",
      },
      { status: 400 },
    )
  }
}
