import { type NextRequest, NextResponse } from "next/server"

// Mock database
const financialData = {
  totalIncome: 319000,
  totalExpenses: 267000,
  taxableIncome: 52000,
  expenses: [
    { category: "Maintenance", amount: 12500, tax: "Deductible" },
    { category: "Utilities", amount: 8300, tax: "Deductible" },
    { category: "Insurance", amount: 5200, tax: "Deductible" },
    { category: "Property Tax", amount: 15000, tax: "Deductible" },
    { category: "Management", amount: 4800, tax: "Deductible" },
    { category: "Cleaning", amount: 2100, tax: "Deductible" },
  ],
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const category = searchParams.get("category")

    if (category) {
      const expense = financialData.expenses.find((e) => e.category === category)
      return NextResponse.json({
        success: true,
        data: expense || null,
      })
    }

    return NextResponse.json({
      success: true,
      data: financialData,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch financial data",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { category, amount } = body

    const existingExpense = financialData.expenses.find((e) => e.category === category)
    if (existingExpense) {
      existingExpense.amount = amount
    } else {
      financialData.expenses.push({ category, amount, tax: "Deductible" })
    }

    return NextResponse.json(
      {
        success: true,
        data: financialData,
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to save financial data",
      },
      { status: 400 },
    )
  }
}
