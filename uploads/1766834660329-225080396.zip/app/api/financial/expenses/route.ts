import { NextResponse } from "next/server"

export async function GET() {
  const expenses = [
    {
      id: "EXP-001",
      category: "Maintenance",
      amount: 12500,
      tax_status: "deductible",
      date: "2024-06-15",
      description: "HVAC repairs and maintenance",
    },
    {
      id: "EXP-002",
      category: "Utilities",
      amount: 8300,
      tax_status: "deductible",
      date: "2024-06-10",
      description: "Electric and water utilities",
    },
    {
      id: "EXP-003",
      category: "Insurance",
      amount: 5200,
      tax_status: "deductible",
      date: "2024-06-01",
      description: "Property liability insurance",
    },
  ]

  return NextResponse.json(expenses)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    const newExpense = {
      id: `EXP-${Date.now()}`,
      ...body,
      tax_status: "pending_review",
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(newExpense, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create expense" }, { status: 400 })
  }
}
