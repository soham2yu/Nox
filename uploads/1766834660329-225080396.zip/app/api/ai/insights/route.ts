import { NextResponse } from "next/server"

export async function GET() {
  const insights = [
    {
      type: "churn_risk",
      property_id: "1",
      tenant_id: "T-402",
      risk_score: 0.85,
      factors: ["high_complaints", "market_below_avg", "lease_ending_soon"],
      recommendation: "Consider 8-12% pricing reduction or renewal incentives",
      action_priority: "high",
    },
    {
      type: "pricing_optimization",
      property_id: "2",
      market_gap: 0.05,
      potential_revenue: 850,
      recommendation: "Gradually increase pricing on renewal units",
      action_priority: "medium",
    },
    {
      type: "preventative_maintenance",
      property_id: "1",
      system: "HVAC_Building_A",
      days_until_maintenance: 14,
      cost_if_proactive: 2500,
      cost_if_emergency: 8500,
      recommendation: "Schedule proactive maintenance in 2-3 weeks",
      action_priority: "medium",
    },
  ]

  return NextResponse.json(insights)
}
