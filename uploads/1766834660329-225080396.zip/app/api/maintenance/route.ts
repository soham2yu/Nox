import { type NextRequest, NextResponse } from "next/server"

// Mock database
const tickets = [
  {
    id: "MNT-001",
    property: "Sunset Apartments, Unit 302",
    issue: "Leaking kitchen faucet",
    priority: "high",
    status: "urgent",
    technician: "John Smith",
    created: new Date("2024-01-05").toISOString(),
  },
  {
    id: "MNT-002",
    property: "Downtown Towers, Unit 501",
    issue: "HVAC system maintenance",
    priority: "medium",
    status: "in-progress",
    technician: "Maria Garcia",
    created: new Date("2024-01-02").toISOString(),
  },
]

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get("status")

    const filtered = status ? tickets.filter((t) => t.status === status) : tickets

    return NextResponse.json({
      success: true,
      data: filtered,
      count: filtered.length,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch maintenance tickets",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const newTicket = {
      id: `MNT-${String(tickets.length + 1).padStart(3, "0")}`,
      created: new Date().toISOString(),
      ...body,
    }
    tickets.push(newTicket)
    return NextResponse.json(
      {
        success: true,
        data: newTicket,
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to create maintenance ticket",
      },
      { status: 400 },
    )
  }
}
