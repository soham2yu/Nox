import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const status = searchParams.get("status")

  const tickets = [
    {
      id: "MNT-001",
      property: "Sunset Apartments, Unit 302",
      issue: "Leaking kitchen faucet",
      priority: "high",
      status: "urgent",
      technician: "John Smith",
      created: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "MNT-002",
      property: "Downtown Towers, Unit 501",
      issue: "HVAC system maintenance",
      priority: "medium",
      status: "in-progress",
      technician: "Maria Garcia",
      created: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    },
  ]

  const filtered = status ? tickets.filter((t) => t.status === status) : tickets
  return NextResponse.json(filtered)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    const newTicket = {
      id: `MNT-${Date.now()}`,
      ...body,
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(newTicket, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create ticket" }, { status: 400 })
  }
}
