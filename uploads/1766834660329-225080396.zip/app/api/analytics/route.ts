import { type NextRequest, NextResponse } from "next/server"

// Analytics aggregation endpoint
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const period = searchParams.get("period") || "month"

    // Mock aggregated analytics
    const analytics = {
      period,
      occupancyRate: 0.964,
      totalTickets: 188,
      pendingTickets: 23,
      urgentTickets: 8,
      openDisputes: 2,
      resolvedThisMonth: 12,
      avgResolutionTime: 4.2,
      monthlyRevenue: 58000,
      monthlyExpenses: 47000,
      netIncome: 11000,
    }

    return NextResponse.json({
      success: true,
      data: analytics,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch analytics",
      },
      { status: 500 },
    )
  }
}
