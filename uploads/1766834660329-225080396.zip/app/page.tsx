"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import ShaderBackground from "@/components/ui/shader-background"
import { ArrowRight, BarChart3, Wrench, Users, MessageSquare, Building2, TrendingUp } from "lucide-react"

const features = [
  {
    icon: Building2,
    title: "Property Management",
    description: "Centralized dashboard for all your properties with real-time occupancy tracking",
  },
  {
    icon: BarChart3,
    title: "AI Insights",
    description: "Predictive analytics for tenant churn and dynamic pricing optimization",
  },
  {
    icon: Wrench,
    title: "Smart Maintenance",
    description: "Automated ticket creation with AI image recognition and technician dispatch",
  },
  {
    icon: Users,
    title: "Tenant Management",
    description: "Complete tenant lifecycle management with automated communications",
  },
  {
    icon: TrendingUp,
    title: "Financial Analytics",
    description: "Expense categorization and tax optimization in one place",
  },
  {
    icon: MessageSquare,
    title: "Dispute Resolution",
    description: "Secure messaging and automated dispute tracking system",
  },
]

const stats = [
  { number: "10K+", label: "Properties Managed" },
  { number: "95%", label: "Occupancy Rate" },
  { number: "2.5M+", label: "Monthly Revenue" },
]

export default function LandingPage() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20)
    window.addEventListener("scroll", handleScroll)

    const user = localStorage.getItem("user")
    if (user) {
      setIsLoggedIn(true)
    }

    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <main className="min-h-screen w-full bg-background text-foreground">
      <ShaderBackground />

      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "bg-card/80 backdrop-blur-lg border-b border-border shadow-lg" : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 font-bold text-xl text-primary"
          >
            <Building2 className="w-6 h-6" />
            PropertyHub
          </motion.div>

          <div className="flex items-center gap-4">
            {isLoggedIn ? (
              <Link
                href="/dashboard"
                className="px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95"
              >
                Dashboard <ArrowRight className="w-4 h-4" />
              </Link>
            ) : (
              <>
                <Link
                  href="/login"
                  className="px-4 py-2 rounded-lg font-medium transition-all border border-border text-foreground hover:bg-muted"
                >
                  Sign In
                </Link>
                <Link
                  href="/signup"
                  className="px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95"
                >
                  Get Started <ArrowRight className="w-4 h-4" />
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      <section className="relative min-h-screen flex items-center justify-center px-6 pt-20">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-block mb-6 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
              <span className="text-primary text-sm font-semibold">AI-Powered Property Management</span>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl md:text-6xl font-bold mb-6 leading-tight"
          >
            Transform Your Property <span className="text-primary">Management</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto"
          >
            Maximize occupancy and revenue with AI-driven insights, smart maintenance, and automated tenant
            communications.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link
              href="/signup"
              className="px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95 px-8 py-3 text-lg"
            >
              Start Free Trial
            </Link>
            <Link
              href="#features"
              className="px-4 py-2 rounded-lg font-medium transition-all border border-border text-foreground hover:bg-muted px-8 py-3 text-lg"
            >
              Learn More
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-3 gap-8 mt-20 pt-12 border-t border-border"
          >
            {stats.map((stat, index) => (
              <div key={index} className="space-y-2">
                <div className="text-3xl font-bold text-primary">{stat.number}</div>
                <div className="text-muted-foreground text-sm">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      <section id="features" className="relative py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">Powerful Features</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Everything you need to manage properties efficiently and profitably
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="rounded-xl bg-card border border-border shadow-lg p-8 hover:shadow-xl transition-all hover:border-primary/30"
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      <section className="relative py-20 px-6">
        <div className="max-w-4xl mx-auto rounded-xl bg-card border border-border shadow-lg p-12 md:p-16 text-center hover:shadow-xl transition-all hover:border-primary/30">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Optimize Your Properties?</h2>
            <p className="text-muted-foreground text-lg mb-8">
              Join hundreds of property managers saving time and increasing revenue with PropertyHub
            </p>
            <Link
              href="/signup"
              className="px-4 py-2 rounded-lg font-medium transition-all bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/30 hover:scale-105 active:scale-95 px-8 py-3 text-lg inline-block"
            >
              Start Your Free Trial Today
            </Link>
          </motion.div>
        </div>
      </section>

      <footer className="relative border-t border-border py-12 px-6 mt-20">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2 text-primary font-bold text-lg">
              <Building2 className="w-5 h-5" />
              PropertyHub
            </div>
            <div className="flex items-center gap-8 text-muted-foreground text-sm">
              <Link href="#" className="hover:text-foreground transition-colors">
                Privacy
              </Link>
              <Link href="#" className="hover:text-foreground transition-colors">
                Terms
              </Link>
              <Link href="#" className="hover:text-foreground transition-colors">
                Contact
              </Link>
            </div>
            <div className="text-muted-foreground text-sm">© 2025 PropertyHub. All rights reserved.</div>
          </div>
        </div>
      </footer>
    </main>
  )
}
