"use client"

import { Card } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts"
import { DollarSign, TrendingUp, FileText } from "lucide-react"

const expenseData = [
  { category: "Maintenance", amount: 12500, tax: "Deductible" },
  { category: "Utilities", amount: 8300, tax: "Deductible" },
  { category: "Insurance", amount: 5200, tax: "Deductible" },
  { category: "Property Tax", amount: 15000, tax: "Deductible" },
  { category: "Management", amount: 4800, tax: "Deductible" },
  { category: "Cleaning", amount: 2100, tax: "Deductible" },
]

const monthlyTaxData = [
  { month: "Jan", income: 48000, expenses: 42000, taxable: 6000 },
  { month: "Feb", income: 51000, expenses: 43500, taxable: 7500 },
  { month: "Mar", income: 54000, expenses: 44000, taxable: 10000 },
  { month: "Apr", income: 52000, expenses: 45000, taxable: 7000 },
  { month: "May", income: 56000, expenses: 45500, taxable: 10500 },
  { month: "Jun", income: 58000, expenses: 47000, taxable: 11000 },
]

export default function FinancialDashboard() {
  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent mb-2">
          Financial Management
        </h1>
        <p className="text-purple-300">Automated expense categorization for seamless tax preparation</p>
      </div>

      {/* Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card className="bg-slate-800/50 border-purple-500/20 p-6 hover:border-purple-500/40 transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-purple-300 text-sm mb-1">Total Income (YTD)</p>
              <p className="text-3xl font-bold text-white">$319K</p>
              <p className="text-green-400 text-xs mt-2">From 45 properties</p>
            </div>
            <DollarSign className="text-green-400 h-8 w-8" />
          </div>
        </Card>

        <Card className="bg-slate-800/50 border-purple-500/20 p-6 hover:border-purple-500/40 transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-purple-300 text-sm mb-1">Total Expenses (YTD)</p>
              <p className="text-3xl font-bold text-white">$267K</p>
              <p className="text-blue-400 text-xs mt-2">Automatically categorized</p>
            </div>
            <FileText className="text-blue-400 h-8 w-8" />
          </div>
        </Card>

        <Card className="bg-slate-800/50 border-purple-500/20 p-6 hover:border-purple-500/40 transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-purple-300 text-sm mb-1">Net Taxable Income</p>
              <p className="text-3xl font-bold text-white">$52K</p>
              <p className="text-purple-400 text-xs mt-2">Ready for tax filing</p>
            </div>
            <TrendingUp className="text-purple-400 h-8 w-8" />
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card className="bg-slate-800/50 border-purple-500/20 p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Expense Categories</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={expenseData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis stroke="#9ca3af" angle={-45} textAnchor="end" height={80} />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{ backgroundColor: "#1f2937", border: "1px solid #6b21a8" }}
                labelStyle={{ color: "#f3e8ff" }}
              />
              <Bar dataKey="amount" fill="#a78bfa" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="bg-slate-800/50 border-purple-500/20 p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Taxable Income Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyTaxData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{ backgroundColor: "#1f2937", border: "1px solid #6b21a8" }}
                labelStyle={{ color: "#f3e8ff" }}
              />
              <Legend />
              <Line type="monotone" dataKey="income" stroke="#a78bfa" strokeWidth={2} />
              <Line type="monotone" dataKey="expenses" stroke="#fca5a5" strokeWidth={2} />
              <Line type="monotone" dataKey="taxable" stroke="#86efac" strokeWidth={2} strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Tax Summary */}
      <Card className="bg-gradient-to-r from-purple-600/20 to-purple-500/10 border-purple-500/30 p-6">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <FileText className="h-5 w-5" /> Tax Preparation Summary
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <p className="text-purple-300 text-sm mb-2">Q2 Tax Status</p>
            <p className="text-white font-semibold mb-2">All expenses auto-categorized and ready for filing</p>
            <p className="text-purple-400 text-sm">• Property maintenance - Fully deductible</p>
            <p className="text-purple-400 text-sm">• Insurance premiums - Fully deductible</p>
            <p className="text-purple-400 text-sm">• Management fees - Fully deductible</p>
          </div>
          <div>
            <p className="text-purple-300 text-sm mb-2">Deduction Summary</p>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-purple-400">Deductible Expenses:</span>
                <span className="text-green-400 font-semibold">$267,000</span>
              </div>
              <div className="flex justify-between">
                <span className="text-purple-400">Net Operating Income:</span>
                <span className="text-green-400 font-semibold">$52,000</span>
              </div>
              <div className="flex justify-between border-t border-purple-500/20 pt-2 mt-2">
                <span className="text-purple-200 font-semibold">Estimated Tax (25%):</span>
                <span className="text-orange-400 font-semibold">$13,000</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
