"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle, Clock, Wrench, Upload, MapPin } from "lucide-react"
import { useState } from "react"

const tickets = [
  {
    id: "MNT-001",
    property: "Sunset Apartments, Unit 302",
    issue: "Leaking kitchen faucet",
    priority: "high",
    status: "urgent",
    technician: "John Smith",
    created: "2 hours ago",
  },
  {
    id: "MNT-002",
    property: "Downtown Towers, Unit 501",
    issue: "HVAC system maintenance",
    priority: "medium",
    status: "in-progress",
    technician: "Maria Garcia",
    created: "5 hours ago",
  },
  {
    id: "MNT-003",
    property: "Park View Complex, Common Area",
    issue: "Parking lot lighting repair",
    priority: "medium",
    status: "scheduled",
    technician: "Unassigned",
    created: "1 day ago",
  },
  {
    id: "MNT-004",
    property: "Riverside Lofts, Unit 104",
    issue: "Bathroom tile replacement",
    priority: "low",
    status: "completed",
    technician: "Alex Johnson",
    created: "3 days ago",
  },
]

const statusColors = {
  urgent: { bg: "bg-red-500/10", text: "text-red-400", border: "border-red-500/20" },
  "in-progress": { bg: "bg-blue-500/10", text: "text-blue-400", border: "border-blue-500/20" },
  scheduled: { bg: "bg-yellow-500/10", text: "text-yellow-400", border: "border-yellow-500/20" },
  completed: { bg: "bg-green-500/10", text: "text-green-400", border: "border-green-500/20" },
}

export default function MaintenanceHub() {
  const [selectedTicket, setSelectedTicket] = useState(null)

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent mb-2">
            Maintenance Management
          </h1>
          <p className="text-purple-300">Smart tickets with AI image recognition & technician dispatch</p>
        </div>
        <Button className="bg-purple-600 hover:bg-purple-700 text-white">
          <Wrench className="h-4 w-4 mr-2" /> Create Ticket
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Tickets List */}
        <div className="lg:col-span-2 space-y-4">
          {tickets.map((ticket) => (
            <Card
              key={ticket.id}
              className={`bg-slate-800/50 border-purple-500/20 p-6 cursor-pointer hover:border-purple-500/40 transition-all ${
                selectedTicket?.id === ticket.id ? "border-purple-500" : ""
              }`}
              onClick={() => setSelectedTicket(ticket)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-sm font-mono text-purple-400">{ticket.id}</span>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        statusColors[ticket.status].bg
                      } ${statusColors[ticket.status].text} border ${statusColors[ticket.status].border}`}
                    >
                      {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{ticket.issue}</h3>
                  <p className="text-purple-300 flex items-center gap-2">
                    <MapPin className="h-4 w-4" /> {ticket.property}
                  </p>
                </div>
                {ticket.status === "urgent" && <AlertCircle className="text-red-400 h-6 w-6" />}
                {ticket.status === "completed" && <CheckCircle className="text-green-400 h-6 w-6" />}
                {ticket.status === "in-progress" && <Clock className="text-blue-400 h-6 w-6" />}
              </div>

              <div className="flex items-center justify-between text-sm text-purple-400">
                <span>Tech: {ticket.technician}</span>
                <span>{ticket.created}</span>
              </div>
            </Card>
          ))}
        </div>

        {/* Ticket Details */}
        <div>
          {selectedTicket ? (
            <Card className="bg-slate-800/50 border-purple-500/20 p-6 sticky top-8">
              <h3 className="text-xl font-bold text-white mb-4">Ticket Details</h3>

              <div className="space-y-4">
                <div>
                  <p className="text-purple-300 text-sm mb-1">Ticket ID</p>
                  <p className="text-white font-mono">{selectedTicket.id}</p>
                </div>

                <div>
                  <p className="text-purple-300 text-sm mb-1">Property</p>
                  <p className="text-white">{selectedTicket.property}</p>
                </div>

                <div>
                  <p className="text-purple-300 text-sm mb-1">Issue Description</p>
                  <p className="text-white">{selectedTicket.issue}</p>
                </div>

                <div>
                  <p className="text-purple-300 text-sm mb-1">Assigned Technician</p>
                  <p className="text-white">{selectedTicket.technician}</p>
                </div>

                <div className="pt-4 border-t border-purple-500/20">
                  <p className="text-purple-300 text-sm mb-3">Upload Photo/Video</p>
                  <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white mb-2">
                    <Upload className="h-4 w-4 mr-2" /> Add Media
                  </Button>
                  <p className="text-xs text-purple-400">AI will automatically analyze for issue detection</p>
                </div>

                <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white mt-6">Update Status</Button>
              </div>
            </Card>
          ) : (
            <Card className="bg-slate-800/50 border-purple-500/20 p-6 text-center">
              <p className="text-purple-300">Select a ticket to view details</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
