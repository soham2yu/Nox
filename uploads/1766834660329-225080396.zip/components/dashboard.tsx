"use client"

import { Card } from "@/components/ui/card"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { TrendingUp, AlertCircle, CheckCircle, Clock } from "lucide-react"

const occupancyData = [
  { month: "Jan", occupancy: 92, target: 95 },
  { month: "Feb", occupancy: 94, target: 95 },
  { month: "Mar", occupancy: 96, target: 95 },
  { month: "Apr", occupancy: 95, target: 95 },
  { month: "May", occupancy: 97, target: 95 },
  { month: "Jun", occupancy: 98, target: 95 },
]

const maintenanceData = [
  { name: "Completed", value: 157, color: "#10b981" },
  { name: "Pending", value: 23, color: "#f59e0b" },
  { name: "Urgent", value: 8, color: "#ef4444" },
]

const revenueData = [
  { month: "Jan", revenue: 48000, expenses: 12000 },
  { month: "Feb", revenue: 51000, expenses: 13000 },
  { month: "Mar", revenue: 54000, expenses: 12500 },
  { month: "Apr", revenue: 52000, expenses: 13500 },
  { month: "May", revenue: 56000, expenses: 13000 },
  { month: "Jun", revenue: 58000, expenses: 14000 },
]

export default function Dashboard() {
  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent mb-2">
          Property Management Dashboard
        </h1>
        <p className="text-purple-300">Real-time insights and property performance metrics</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-slate-800/50 border-purple-500/20 p-6 hover:border-purple-500/40 transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-purple-300 text-sm mb-1">Occupancy Rate</p>
              <p className="text-3xl font-bold text-white">98%</p>
              <p className="text-green-400 text-xs mt-2 flex items-center gap-1">
                <TrendingUp className="h-3 w-3" /> +3% from last month
              </p>
            </div>
            <CheckCircle className="text-green-400 h-8 w-8" />
          </div>
        </Card>

        <Card className="bg-slate-800/50 border-purple-500/20 p-6 hover:border-purple-500/40 transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-purple-300 text-sm mb-1">Maintenance Tickets</p>
              <p className="text-3xl font-bold text-white">188</p>
              <p className="text-orange-400 text-xs mt-2">23 pending, 8 urgent</p>
            </div>
            <AlertCircle className="text-orange-400 h-8 w-8" />
          </div>
        </Card>

        <Card className="bg-slate-800/50 border-purple-500/20 p-6 hover:border-purple-500/40 transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-purple-300 text-sm mb-1">Monthly Revenue</p>
              <p className="text-3xl font-bold text-white">$58K</p>
              <p className="text-green-400 text-xs mt-2">+$2K from previous month</p>
            </div>
            <TrendingUp className="text-purple-400 h-8 w-8" />
          </div>
        </Card>

        <Card className="bg-slate-800/50 border-purple-500/20 p-6 hover:border-purple-500/40 transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-purple-300 text-sm mb-1">Response Time</p>
              <p className="text-3xl font-bold text-white">2.3h</p>
              <p className="text-blue-400 text-xs mt-2">Average maintenance response</p>
            </div>
            <Clock className="text-blue-400 h-8 w-8" />
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card className="bg-slate-800/50 border-purple-500/20 p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Occupancy Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={occupancyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{ backgroundColor: "#1f2937", border: "1px solid #6b21a8" }}
                labelStyle={{ color: "#f3e8ff" }}
              />
              <Legend />
              <Line type="monotone" dataKey="occupancy" stroke="#a78bfa" strokeWidth={2} />
              <Line type="monotone" dataKey="target" stroke="#8b5cf6" strokeDasharray="5 5" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="bg-slate-800/50 border-purple-500/20 p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Revenue vs Expenses</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{ backgroundColor: "#1f2937", border: "1px solid #6b21a8" }}
                labelStyle={{ color: "#f3e8ff" }}
              />
              <Legend />
              <Bar dataKey="revenue" fill="#a78bfa" />
              <Bar dataKey="expenses" fill="#fca5a5" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Maintenance Status */}
      <Card className="bg-slate-800/50 border-purple-500/20 p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Maintenance Status Overview</h3>
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="w-full md:w-1/3 flex justify-center mb-4 md:mb-0">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={maintenanceData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value">
                  {maintenanceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="w-full md:w-2/3 md:pl-8">
            {maintenanceData.map((item, idx) => (
              <div key={idx} className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                  <span className="text-purple-200">{item.name}</span>
                </div>
                <span className="text-white font-semibold">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  )
}
