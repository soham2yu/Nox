"use client"

import { Card } from "@/components/ui/card"
import { TrendingDown, AlertTriangle, Zap } from "lucide-react"

const insights = [
  {
    title: "Tenant Churn Risk - Unit 402",
    description: "High likelihood of lease non-renewal detected based on complaint history and market comparison.",
    risk: "High",
    recommendation: "Consider dynamic pricing reduction of 8-12% or lease renewal incentives.",
    icon: AlertTriangle,
    color: "text-red-400",
  },
  {
    title: "Dynamic Pricing Opportunity",
    description: "Market comps analysis shows current pricing is 5% below market rate for comparable units.",
    opportunity: "+ $850/month potential revenue",
    recommendation: "Gradually increase pricing on renewal units starting next quarter.",
    icon: Zap,
    color: "text-green-400",
  },
  {
    title: "Preventative Maintenance Alert",
    description: "HVAC systems in Building A approaching scheduled maintenance window (2-3 weeks).",
    status: "Scheduled",
    recommendation: "Proactive maintenance will prevent emergency calls and reduce downtime.",
    icon: TrendingDown,
    color: "text-blue-400",
  },
]

export default function AIInsights() {
  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent mb-2">
          AI-Driven Insights
        </h1>
        <p className="text-purple-300">Proactive analytics for tenant retention and revenue optimization</p>
      </div>

      <div className="space-y-6">
        {insights.map((insight, idx) => {
          const Icon = insight.icon
          return (
            <Card
              key={idx}
              className="bg-slate-800/50 border-purple-500/20 p-6 hover:border-purple-500/40 transition-all"
            >
              <div className="flex items-start gap-4">
                <div className={`${insight.color} mt-1`}>
                  <Icon className="h-6 w-6" />
                </div>

                <div className="flex-1">
                  <h3 className="text-xl font-bold text-white mb-2">{insight.title}</h3>
                  <p className="text-purple-300 mb-4">{insight.description}</p>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    {insight.risk && (
                      <div>
                        <p className="text-purple-400 text-sm">Risk Level</p>
                        <p className="text-red-400 font-semibold">{insight.risk}</p>
                      </div>
                    )}
                    {insight.opportunity && (
                      <div>
                        <p className="text-purple-400 text-sm">Opportunity</p>
                        <p className="text-green-400 font-semibold">{insight.opportunity}</p>
                      </div>
                    )}
                    {insight.status && (
                      <div>
                        <p className="text-purple-400 text-sm">Status</p>
                        <p className="text-blue-400 font-semibold">{insight.status}</p>
                      </div>
                    )}
                  </div>

                  <div className="bg-slate-700/30 rounded-lg p-3 border border-purple-500/10">
                    <p className="text-sm text-purple-300">
                      <span className="font-semibold">Recommendation:</span> {insight.recommendation}
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          )
        })}
      </div>

      {/* AI Model Info */}
      <Card className="bg-gradient-to-r from-purple-600/20 to-purple-500/10 border-purple-500/30 p-6 mt-8">
        <h3 className="text-lg font-bold text-white mb-2">Advanced Analytics Engine</h3>
        <p className="text-purple-200">
          Our AI system analyzes 50+ data points including tenant history, market comps, maintenance patterns, and
          seasonal trends to deliver predictive insights. Real-time updates ensure you're always one step ahead.
        </p>
      </Card>
    </div>
  )
}
