"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle, Clock, Send, MessageCircle, AlertTriangle } from "lucide-react"
import { useState } from "react"

const disputes = [
  {
    id: "DSP-001",
    tenant: "Sarah Johnson",
    property: "Sunset Apartments, Unit 302",
    subject: "Noise complaint - recurring issue",
    status: "open",
    priority: "high",
    created: "2 days ago",
    messages: 5,
    resolution: "Pending mediation",
  },
  {
    id: "DSP-002",
    tenant: "Michael Chen",
    property: "Downtown Towers, Unit 501",
    subject: "Maintenance request not addressed",
    status: "in-review",
    priority: "medium",
    created: "5 days ago",
    messages: 3,
    resolution: "Under investigation",
  },
  {
    id: "DSP-003",
    tenant: "Emma Rodriguez",
    property: "Park View Complex, Unit 204",
    subject: "Lease violation - unauthorized pet",
    status: "resolved",
    priority: "medium",
    created: "10 days ago",
    messages: 8,
    resolution: "Pet deposit collected",
  },
  {
    id: "DSP-004",
    tenant: "James Wilson",
    property: "Riverside Lofts, Unit 104",
    subject: "Rent payment dispute",
    status: "open",
    priority: "critical",
    created: "3 days ago",
    messages: 12,
    resolution: "Payment plan negotiation",
  },
]

const statusColors = {
  open: { bg: "bg-red-500/10", text: "text-red-400", border: "border-red-500/20" },
  "in-review": { bg: "bg-yellow-500/10", text: "text-yellow-400", border: "border-yellow-500/20" },
  resolved: { bg: "bg-green-500/10", text: "text-green-400", border: "border-green-500/20" },
}

const priorityColors = {
  critical: { bg: "bg-red-600", text: "text-white" },
  high: { bg: "bg-red-500", text: "text-white" },
  medium: { bg: "bg-orange-500", text: "text-white" },
  low: { bg: "bg-blue-500", text: "text-white" },
}

export default function CommunicationHub() {
  const [selectedDispute, setSelectedDispute] = useState(disputes[0])
  const [messageText, setMessageText] = useState("")
  const [replyMode, setReplyMode] = useState(false)

  const handleSendMessage = () => {
    if (messageText.trim()) {
      setMessageText("")
      setReplyMode(false)
    }
  }

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent mb-2">
            Tenant Communications
          </h1>
          <p className="text-purple-300">Manage disputes, messages, and tenant relations</p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-purple-600 hover:bg-purple-700 text-white">
            <MessageCircle className="h-4 w-4 mr-2" /> New Message
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card className="bg-slate-800/50 border-purple-500/20 p-4">
          <p className="text-purple-300 text-sm mb-1">Open Disputes</p>
          <p className="text-2xl font-bold text-white">2</p>
        </Card>
        <Card className="bg-slate-800/50 border-purple-500/20 p-4">
          <p className="text-purple-300 text-sm mb-1">In Review</p>
          <p className="text-2xl font-bold text-white">1</p>
        </Card>
        <Card className="bg-slate-800/50 border-purple-500/20 p-4">
          <p className="text-purple-300 text-sm mb-1">Resolved This Month</p>
          <p className="text-2xl font-bold text-white">12</p>
        </Card>
        <Card className="bg-slate-800/50 border-purple-500/20 p-4">
          <p className="text-purple-300 text-sm mb-1">Avg Resolution Time</p>
          <p className="text-2xl font-bold text-white">4.2 days</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Disputes List */}
        <div className="lg:col-span-2 space-y-3">
          <h2 className="text-xl font-semibold text-white mb-4">Active Disputes</h2>
          {disputes.map((dispute) => (
            <Card
              key={dispute.id}
              className={`bg-slate-800/50 border-purple-500/20 p-5 cursor-pointer hover:border-purple-500/40 transition-all ${
                selectedDispute?.id === dispute.id ? "border-purple-500" : ""
              }`}
              onClick={() => setSelectedDispute(dispute)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-mono text-purple-400">{dispute.id}</span>
                    <span
                      className={`px-2 py-1 rounded text-xs font-semibold ${
                        statusColors[dispute.status].bg
                      } ${statusColors[dispute.status].text} border ${statusColors[dispute.status].border}`}
                    >
                      {dispute.status.charAt(0).toUpperCase() + dispute.status.slice(1)}
                    </span>
                    <span
                      className={`px-2 py-1 rounded text-xs font-semibold ${priorityColors[dispute.priority].bg} ${priorityColors[dispute.priority].text}`}
                    >
                      {dispute.priority.charAt(0).toUpperCase() + dispute.priority.slice(1)}
                    </span>
                  </div>
                  <h3 className="font-semibold text-white mb-1">{dispute.subject}</h3>
                  <p className="text-sm text-purple-300">
                    {dispute.tenant} • {dispute.property}
                  </p>
                </div>
                {dispute.status === "open" && <AlertTriangle className="text-red-400 h-5 w-5" />}
                {dispute.status === "in-review" && <Clock className="text-yellow-400 h-5 w-5" />}
                {dispute.status === "resolved" && <CheckCircle className="text-green-400 h-5 w-5" />}
              </div>
              <div className="flex justify-between text-xs text-purple-400">
                <span>{dispute.messages} messages</span>
                <span>{dispute.created}</span>
              </div>
            </Card>
          ))}
        </div>

        {/* Dispute Details & Chat */}
        <div>
          {selectedDispute ? (
            <Card className="bg-slate-800/50 border-purple-500/20 p-6 sticky top-8">
              <h3 className="text-xl font-bold text-white mb-4">Dispute Details</h3>

              <div className="space-y-4 mb-6">
                <div>
                  <p className="text-purple-300 text-xs uppercase tracking-wide mb-1">ID</p>
                  <p className="text-white font-mono">{selectedDispute.id}</p>
                </div>

                <div>
                  <p className="text-purple-300 text-xs uppercase tracking-wide mb-1">Tenant</p>
                  <p className="text-white">{selectedDispute.tenant}</p>
                </div>

                <div>
                  <p className="text-purple-300 text-xs uppercase tracking-wide mb-1">Property</p>
                  <p className="text-white text-sm">{selectedDispute.property}</p>
                </div>

                <div>
                  <p className="text-purple-300 text-xs uppercase tracking-wide mb-1">Resolution Status</p>
                  <p className="text-purple-200 text-sm">{selectedDispute.resolution}</p>
                </div>
              </div>

              <div className="border-t border-purple-500/20 pt-4 mb-4">
                <h4 className="text-sm font-semibold text-white mb-2">Send Message</h4>
                {!replyMode ? (
                  <Button
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white text-sm"
                    onClick={() => setReplyMode(true)}
                  >
                    <MessageCircle className="h-4 w-4 mr-2" /> Reply to Tenant
                  </Button>
                ) : (
                  <div className="space-y-2">
                    <Textarea
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder="Type your message..."
                      className="bg-slate-700/50 border-purple-500/20 text-white text-sm min-h-24"
                    />
                    <div className="flex gap-2">
                      <Button
                        className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-sm"
                        onClick={handleSendMessage}
                      >
                        <Send className="h-4 w-4 mr-2" /> Send
                      </Button>
                      <Button
                        variant="outline"
                        className="text-purple-300 border-purple-500/20 hover:bg-purple-500/10 text-sm bg-transparent"
                        onClick={() => {
                          setReplyMode(false)
                          setMessageText("")
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              <Button className="w-full bg-purple-700 hover:bg-purple-800 text-white text-sm mt-4">
                Mark as Resolved
              </Button>
            </Card>
          ) : (
            <Card className="bg-slate-800/50 border-purple-500/20 p-6 text-center">
              <p className="text-purple-300">Select a dispute to view details</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
